"""
Student Academy System v2 — Python Flask Backend
pip install flask flask-cors
python app.py  →  http://localhost:5000
"""
from flask import Flask, request, jsonify, session
from flask_cors import CORS
import sqlite3, os, hashlib, secrets
from datetime import datetime, date

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)
CORS(app, supports_credentials=True, origins=["*"])

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'database', 'academy.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_db()
    schema = os.path.join(os.path.dirname(__file__), '..', 'database', 'schema.sql')
    with open(schema) as f:
        conn.executescript(f.read())
    conn.commit(); conn.close()
    print("✅ DB ready")

def hash_pw(password, salt=None):
    if not salt: salt = secrets.token_hex(16)
    h = hashlib.sha256((password + salt).encode()).hexdigest()
    return f"{salt}:{h}"

def check_pw(password, stored):
    if ':' in stored:
        salt, h = stored.split(':', 1)
        return hashlib.sha256((password + salt).encode()).hexdigest() == h
    # legacy demo check
    return stored == f"admin:{password}"

def calc_grade(m):
    return 'A+' if m>=95 else 'A' if m>=90 else 'B+' if m>=85 else 'B' if m>=80 else 'C+' if m>=75 else 'C' if m>=70 else 'D' if m>=60 else 'F'

# ── AUTH ──────────────────────────────────────────────────────────────────────

@app.route('/api/signup', methods=['POST'])
def signup():
    d = request.get_json()
    name  = d.get('student_name','').strip()
    email = d.get('email','').strip()
    pwd   = d.get('password','')
    regno = d.get('regno','').strip().upper()
    dept  = d.get('department','General').strip()
    if not all([name, email, pwd, regno]):
        return jsonify({'success':False,'message':'All fields are required'}), 400
    if len(pwd) < 6:
        return jsonify({'success':False,'message':'Password must be at least 6 characters'}), 400
    conn = get_db()
    try:
        if conn.execute('SELECT id FROM users WHERE email=? OR regno=?',(email,regno)).fetchone():
            return jsonify({'success':False,'message':'Email or Registration Number already exists'}), 409
        conn.execute(
            'INSERT INTO users (student_name,email,password_hash,regno,role,department) VALUES (?,?,?,?,?,?)',
            (name, email, hash_pw(pwd), regno, 'student', dept)
        )
        conn.commit()
        return jsonify({'success':True,'message':'Account created! Please log in.'})
    except Exception as e:
        return jsonify({'success':False,'message':str(e)}), 500
    finally: conn.close()

@app.route('/api/login', methods=['POST'])
def login():
    d = request.get_json()
    identifier = d.get('identifier','').strip()
    pwd        = d.get('password','')
    conn = get_db()
    try:
        u = conn.execute(
            'SELECT * FROM users WHERE email=? OR regno=?',(identifier, identifier.upper())
        ).fetchone()
        if not u:
            return jsonify({'success':False,'message':'Invalid email/regno or password'}), 401
        ok = check_pw(pwd, u['password_hash'])
        # allow admin demo
        if not ok and u['role']=='admin' and pwd=='admin123':
            ok = True
        if not ok:
            return jsonify({'success':False,'message':'Invalid email/regno or password'}), 401
        session['user_id']   = u['id']
        session['username']  = u['student_name']
        session['role']      = u['role']
        session['regno']     = u['regno']
        return jsonify({'success':True,'user':{
            'id':u['id'],'student_name':u['student_name'],
            'email':u['email'],'regno':u['regno'],'role':u['role'],'department':u['department']
        }})
    finally: conn.close()

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success':True})

@app.route('/api/check-auth')
def check_auth():
    return jsonify({'authenticated':'user_id' in session,'username':session.get('username'),'role':session.get('role')})

# ── STUDENTS ──────────────────────────────────────────────────────────────────

@app.route('/api/students', methods=['GET','POST'])
def students():
    conn = get_db()
    try:
        if request.method=='GET':
            rows = conn.execute('SELECT * FROM students ORDER BY first_name').fetchall()
            return jsonify([dict(r) for r in rows])
        d = request.get_json()
        conn.execute('''INSERT INTO students
            (student_id,first_name,last_name,date_of_birth,gender,email,phone,address,enrollment_year,department)
            VALUES(?,?,?,?,?,?,?,?,?,?)''',
            (d.get('student_id'),d.get('first_name'),d.get('last_name'),d.get('date_of_birth'),
             d.get('gender'),d.get('email'),d.get('phone'),d.get('address'),
             d.get('enrollment_year'),d.get('department'))
        )
        conn.commit()
        return jsonify({'success':True})
    except Exception as e:
        return jsonify({'success':False,'message':str(e)}), 500
    finally: conn.close()

@app.route('/api/students/<sid>', methods=['GET'])
def student_by_id(sid):
    conn = get_db()
    s = conn.execute('SELECT * FROM students WHERE student_id=?',(sid,)).fetchone()
    conn.close()
    if not s: return jsonify({'error':'Not found'}), 404
    return jsonify(dict(s))

# ── MARKS ─────────────────────────────────────────────────────────────────────

@app.route('/api/marks', methods=['GET','POST'])
def marks():
    conn = get_db()
    try:
        if request.method=='GET':
            rows = conn.execute('''
                SELECT am.*,s.first_name,s.last_name,s.department
                FROM academic_marks am JOIN students s ON am.student_id=s.student_id
                ORDER BY am.year DESC,am.semester,s.first_name
            ''').fetchall()
            return jsonify([dict(r) for r in rows])
        d = request.get_json()
        m = int(d.get('marks',0))
        g = calc_grade(m)
        conn.execute('''INSERT INTO academic_marks
            (student_id,subject,year,semester,marks,max_marks,grade,teacher,remarks)
            VALUES(?,?,?,?,?,?,?,?,?)''',
            (d.get('student_id'),d.get('subject'),d.get('year'),d.get('semester'),
             m,d.get('max_marks',100),g,d.get('teacher'),d.get('remarks',''))
        )
        conn.commit()
        return jsonify({'success':True,'grade':g})
    except Exception as e:
        return jsonify({'success':False,'message':str(e)}), 500
    finally: conn.close()

@app.route('/api/marks/<sid>', methods=['GET'])
def marks_by_student(sid):
    conn = get_db()
    rows = conn.execute('SELECT * FROM academic_marks WHERE student_id=? ORDER BY year,semester',(sid,)).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route('/api/marks/year/<int:yr>', methods=['GET'])
def marks_by_year(yr):
    conn = get_db()
    rows = conn.execute('''
        SELECT am.*,s.first_name,s.last_name,s.department
        FROM academic_marks am JOIN students s ON am.student_id=s.student_id
        WHERE am.year=? ORDER BY am.semester,s.first_name
    ''',(yr,)).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

# ── ATTENDANCE ────────────────────────────────────────────────────────────────

@app.route('/api/attendance', methods=['GET','POST'])
def attendance():
    conn = get_db()
    try:
        if request.method=='GET':
            sid = request.args.get('student_id')
            subj = request.args.get('subject')
            q = 'SELECT a.*,s.first_name,s.last_name,s.department FROM attendance a JOIN students s ON a.student_id=s.student_id'
            params = []
            if sid:
                q += ' WHERE a.student_id=?'; params.append(sid)
                if subj: q += ' AND a.subject=?'; params.append(subj)
            elif subj:
                q += ' WHERE a.subject=?'; params.append(subj)
            q += ' ORDER BY a.date DESC'
            rows = conn.execute(q, params).fetchall()
            return jsonify([dict(r) for r in rows])
        d = request.get_json()
        conn.execute('''INSERT INTO attendance (student_id,subject,date,status,marked_by,remarks)
            VALUES(?,?,?,?,?,?)''',
            (d.get('student_id'),d.get('subject'),d.get('date'),d.get('status'),
             d.get('marked_by','Teacher'),d.get('remarks',''))
        )
        conn.commit()
        return jsonify({'success':True})
    except Exception as e:
        return jsonify({'success':False,'message':str(e)}), 500
    finally: conn.close()

@app.route('/api/attendance/summary', methods=['GET'])
def attendance_summary():
    conn = get_db()
    try:
        rows = conn.execute('''
            SELECT a.student_id,s.first_name,s.last_name,s.department,
                   COUNT(*) as total,
                   SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) as present,
                   SUM(CASE WHEN a.status='Absent'  THEN 1 ELSE 0 END) as absent,
                   SUM(CASE WHEN a.status='Late'    THEN 1 ELSE 0 END) as late,
                   SUM(CASE WHEN a.status='Excused' THEN 1 ELSE 0 END) as excused
            FROM attendance a JOIN students s ON a.student_id=s.student_id
            GROUP BY a.student_id
            ORDER BY s.first_name
        ''').fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d['percentage'] = round((d['present']+d['late']*0.5)/d['total']*100,1) if d['total'] else 0
            result.append(d)
        return jsonify(result)
    finally: conn.close()

@app.route('/api/attendance/bulk', methods=['POST'])
def attendance_bulk():
    conn = get_db()
    try:
        records = request.get_json()
        for r in records:
            conn.execute('''INSERT INTO attendance (student_id,subject,date,status,marked_by)
                VALUES(?,?,?,?,?)''',
                (r['student_id'],r['subject'],r['date'],r['status'],r.get('marked_by','Teacher'))
            )
        conn.commit()
        return jsonify({'success':True,'count':len(records)})
    except Exception as e:
        return jsonify({'success':False,'message':str(e)}), 500
    finally: conn.close()

# ── HISTORY & STATS ───────────────────────────────────────────────────────────

@app.route('/api/history')
def history():
    conn = get_db()
    rows = conn.execute('SELECT * FROM academy_history ORDER BY event_date').fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route('/api/stats')
def stats():
    conn = get_db()
    try:
        s = conn.execute('SELECT COUNT(*) c FROM students').fetchone()['c']
        m = conn.execute('SELECT COUNT(*) c FROM academic_marks').fetchone()['c']
        a = conn.execute('SELECT AVG(marks) a FROM academic_marks').fetchone()['a']
        d = conn.execute('SELECT COUNT(DISTINCT department) c FROM students').fetchone()['c']
        att = conn.execute("SELECT COUNT(*) c FROM attendance WHERE status='Present'").fetchone()['c']
        att_total = conn.execute('SELECT COUNT(*) c FROM attendance').fetchone()['c']
        att_pct = round(att/att_total*100,1) if att_total else 0
        return jsonify({'total_students':s,'total_marks':m,'avg_marks':round(a or 0,1),'departments':d,'attendance_pct':att_pct})
    finally: conn.close()

if __name__=='__main__':
    init_db()
    print("🎓 Academy Server → http://localhost:5000")
    app.run(debug=True, port=5000, host='0.0.0.0')
