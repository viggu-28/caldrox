/* ═══════════════════════════════════════════
   STUDENT ACADEMY v2 — Shared JS Utilities
   ═══════════════════════════════════════════ */

const API = 'http://localhost:5000/api';

/* ── Demo data (offline mode) ─────────────────────── */
const DEMO = {
  students: [
    {student_id:'STU001',first_name:'Alice',last_name:'Johnson',department:'Computer Science',enrollment_year:2023,gender:'Female',email:'alice@academy.edu',phone:'555-0101'},
    {student_id:'STU002',first_name:'Bob',last_name:'Smith',department:'Mathematics',enrollment_year:2023,gender:'Male',email:'bob@academy.edu',phone:'555-0102'},
    {student_id:'STU003',first_name:'Carol',last_name:'Williams',department:'Physics',enrollment_year:2023,gender:'Female',email:'carol@academy.edu',phone:'555-0103'},
    {student_id:'STU004',first_name:'David',last_name:'Brown',department:'Chemistry',enrollment_year:2023,gender:'Male',email:'david@academy.edu',phone:'555-0104'},
    {student_id:'STU005',first_name:'Emma',last_name:'Davis',department:'Biology',enrollment_year:2023,gender:'Female',email:'emma@academy.edu',phone:'555-0105'}
  ],
  marks: [
    {student_id:'STU001',first_name:'Alice',last_name:'Johnson',department:'CS',subject:'Data Structures',year:2023,semester:'Semester 1',marks:92,grade:'A',teacher:'Prof. Martinez'},
    {student_id:'STU001',first_name:'Alice',last_name:'Johnson',department:'CS',subject:'Algorithms',year:2024,semester:'Semester 2',marks:95,grade:'A+',teacher:'Prof. Martinez'},
    {student_id:'STU001',first_name:'Alice',last_name:'Johnson',department:'CS',subject:'Web Development',year:2024,semester:'Semester 2',marks:96,grade:'A+',teacher:'Prof. Wilson'},
    {student_id:'STU001',first_name:'Alice',last_name:'Johnson',department:'CS',subject:'Database Systems',year:2024,semester:'Semester 2',marks:91,grade:'A',teacher:'Prof. Chen'},
    {student_id:'STU002',first_name:'Bob',last_name:'Smith',department:'Math',subject:'Calculus II',year:2023,semester:'Semester 1',marks:91,grade:'A',teacher:'Prof. Taylor'},
    {student_id:'STU002',first_name:'Bob',last_name:'Smith',department:'Math',subject:'Real Analysis',year:2024,semester:'Semester 2',marks:93,grade:'A',teacher:'Prof. Taylor'},
    {student_id:'STU003',first_name:'Carol',last_name:'Williams',department:'Physics',subject:'Quantum Mechanics',year:2024,semester:'Semester 2',marks:79,grade:'B+',teacher:'Prof. Jackson'},
    {student_id:'STU004',first_name:'David',last_name:'Brown',department:'Chemistry',subject:'Biochemistry',year:2024,semester:'Semester 2',marks:95,grade:'A+',teacher:'Prof. Martin'},
    {student_id:'STU005',first_name:'Emma',last_name:'Davis',department:'Biology',subject:'Cell Biology',year:2023,semester:'Semester 1',marks:96,grade:'A+',teacher:'Prof. Garcia'},
    {student_id:'STU005',first_name:'Emma',last_name:'Davis',department:'Biology',subject:'Genetics',year:2024,semester:'Semester 2',marks:94,grade:'A',teacher:'Prof. Rodriguez'}
  ],
  attendance: [
    {id:1,student_id:'STU001',first_name:'Alice',last_name:'Johnson',department:'CS',subject:'Data Structures',date:'2023-08-01',status:'Present',marked_by:'Prof. Martinez'},
    {id:2,student_id:'STU001',first_name:'Alice',last_name:'Johnson',department:'CS',subject:'Data Structures',date:'2023-08-08',status:'Present',marked_by:'Prof. Martinez'},
    {id:3,student_id:'STU001',first_name:'Alice',last_name:'Johnson',department:'CS',subject:'Data Structures',date:'2023-08-15',status:'Absent',marked_by:'Prof. Martinez'},
    {id:4,student_id:'STU001',first_name:'Alice',last_name:'Johnson',department:'CS',subject:'Algorithms',date:'2024-01-10',status:'Present',marked_by:'Prof. Martinez'},
    {id:5,student_id:'STU001',first_name:'Alice',last_name:'Johnson',department:'CS',subject:'Algorithms',date:'2024-01-17',status:'Present',marked_by:'Prof. Martinez'},
    {id:6,student_id:'STU002',first_name:'Bob',last_name:'Smith',department:'Math',subject:'Calculus II',date:'2023-08-02',status:'Present',marked_by:'Prof. Taylor'},
    {id:7,student_id:'STU002',first_name:'Bob',last_name:'Smith',department:'Math',subject:'Calculus II',date:'2023-08-09',status:'Absent',marked_by:'Prof. Taylor'},
    {id:8,student_id:'STU003',first_name:'Carol',last_name:'Williams',department:'Physics',subject:'Quantum Mechanics',date:'2024-01-11',status:'Present',marked_by:'Prof. Jackson'},
    {id:9,student_id:'STU003',first_name:'Carol',last_name:'Williams',department:'Physics',subject:'Quantum Mechanics',date:'2024-01-18',status:'Absent',marked_by:'Prof. Jackson'},
    {id:10,student_id:'STU004',first_name:'David',last_name:'Brown',department:'Chemistry',subject:'Biochemistry',date:'2024-01-12',status:'Present',marked_by:'Prof. Martin'},
    {id:11,student_id:'STU005',first_name:'Emma',last_name:'Davis',department:'Biology',subject:'Cell Biology',date:'2023-08-01',status:'Present',marked_by:'Prof. Garcia'},
    {id:12,student_id:'STU005',first_name:'Emma',last_name:'Davis',department:'Biology',subject:'Cell Biology',date:'2023-08-08',status:'Late',marked_by:'Prof. Garcia'}
  ],
  attendanceSummary: [
    {student_id:'STU001',first_name:'Alice',last_name:'Johnson',department:'Computer Science',total:25,present:22,absent:2,late:1,excused:0,percentage:89.0},
    {student_id:'STU002',first_name:'Bob',last_name:'Smith',department:'Mathematics',total:20,present:17,absent:2,late:1,excused:0,percentage:87.5},
    {student_id:'STU003',first_name:'Carol',last_name:'Williams',department:'Physics',total:18,present:14,absent:3,late:1,excused:0,percentage:80.6},
    {student_id:'STU004',first_name:'David',last_name:'Brown',department:'Chemistry',total:22,present:19,absent:2,late:1,excused:0,percentage:88.6},
    {student_id:'STU005',first_name:'Emma',last_name:'Davis',department:'Biology',total:24,present:21,absent:2,late:1,excused:0,percentage:89.6}
  ],
  history: [
    {title:'Academy Founded',description:'The Student Academy was established.',event_date:'1985-09-01',category:'Milestone'},
    {title:'First Graduation',description:'The inaugural graduation ceremony.',event_date:'1989-06-15',category:'Ceremony'},
    {title:'International Accreditation',description:'Received international accreditation.',event_date:'2001-11-20',category:'Achievement'},
    {title:'New Campus',description:'State-of-the-art campus opened.',event_date:'2010-01-05',category:'Infrastructure'},
    {title:'Digital Learning',description:'Launched e-learning platforms.',event_date:'2018-07-22',category:'Innovation'},
    {title:'Research Center',description:'Academy Research Center opened.',event_date:'2022-04-18',category:'Achievement'}
  ],
  stats: {total_students:5,total_marks:50,avg_marks:88.4,departments:5,attendance_pct:87.2}
};

/* ── Auth ──────────────────────────────────────────── */
function getUser() { return JSON.parse(localStorage.getItem('acadUser')||'null'); }

function checkAuth() {
  const u = getUser();
  if (!u) { window.location.href='index.html'; return; }
  const el = document.getElementById('navUsername');
  if (el) el.textContent = u.student_name || u.username || 'Student';
  const rg = document.getElementById('navRegno');
  if (rg) rg.textContent = u.regno || '';
}

function logout() {
  try { fetch(`${API}/logout`,{method:'POST',credentials:'include'}); } catch(e){}
  localStorage.removeItem('acadUser');
  window.location.href='index.html';
}

/* ── API ───────────────────────────────────────────── */
async function apiGet(endpoint) {
  try {
    const r = await fetch(API+endpoint,{credentials:'include'});
    if (!r.ok) return null;
    return await r.json();
  } catch(e) { return null; }
}

async function apiPost(endpoint, body) {
  try {
    const r = await fetch(API+endpoint,{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    return await r.json();
  } catch(e) { return null; }
}

/* ── Modal ─────────────────────────────────────────── */
function openModal(id) { const e=document.getElementById(id); if(e){e.classList.add('open');document.body.style.overflow='hidden';} }
function closeModal(id) { const e=document.getElementById(id); if(e){e.classList.remove('open');document.body.style.overflow='';} }
document.addEventListener('keydown',e=>{ if(e.key==='Escape') { document.querySelectorAll('.modal-overlay.open').forEach(m=>{m.classList.remove('open');document.body.style.overflow='';}) }});

/* ── Mobile Nav ────────────────────────────────────── */
function toggleMenu(){document.getElementById('mobileMenu')?.classList.toggle('open');}
document.addEventListener('click',e=>{
  const m=document.getElementById('mobileMenu'),h=document.querySelector('.hamburger');
  if(m&&h&&!m.contains(e.target)&&!h.contains(e.target))m.classList.remove('open');
});

/* ── Animate numbers ───────────────────────────────── */
function animNum(id, target, suffix='') {
  let cur=0; const el=document.getElementById(id); if(!el) return;
  const step=Math.max(1,Math.ceil(target/40));
  const t=setInterval(()=>{ cur=Math.min(cur+step,target); el.textContent=cur+suffix; if(cur>=target)clearInterval(t); },40);
}

/* ── Grade color ───────────────────────────────────── */
function gradeClass(g) {
  if(!g) return '';
  if(g==='A+') return 'gA-plus';
  if(g==='A')  return 'gA';
  if(g==='B+') return 'gB-plus';
  if(g==='B')  return 'gB';
  return 'gC';
}

/* ── Attendance badge ──────────────────────────────── */
function attClass(s) {
  return s==='Present'?'att-present':s==='Absent'?'att-absent':s==='Late'?'att-late':'att-excused';
}

/* ── Attendance % ring ─────────────────────────────── */
function pctRing(pct, size=48) {
  const r=18, c=2*Math.PI*r, dash=Math.round(c*pct/100);
  const col=pct>=85?'#4ade80':pct>=70?'#facc15':'#f87171';
  return `<svg width="${size}" height="${size}" viewBox="0 0 44 44">
    <circle cx="22" cy="22" r="${r}" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="4"/>
    <circle cx="22" cy="22" r="${r}" fill="none" stroke="${col}" stroke-width="4"
      stroke-dasharray="${dash} ${Math.round(c)}" stroke-linecap="round"
      transform="rotate(-90 22 22)"/>
    <text x="22" y="26" text-anchor="middle" fill="${col}" font-size="9" font-weight="700">${pct}%</text>
  </svg>`;
}
