# 🎓 Student Academy History System v2

A full-stack student academic management web app with attendance, 1-year marks history, and realistic background imagery.

---

## 📁 Project Structure

```
academy_v2/
├── frontend/
│   ├── index.html          ← Login & Sign Up
│   ├── dashboard.html      ← Home / History Timeline
│   ├── students.html       ← Student Details
│   ├── marks.html          ← Academic Marks (Full Year)
│   ├── attendance.html     ← Attendance System  ← NEW
│   ├── about.html          ← About Academy
│   ├── css/style.css       ← Full stylesheet (real backgrounds)
│   └── js/main.js          ← Shared utilities + demo data
│
├── backend/python/
│   ├── app.py              ← Flask REST API
│   └── requirements.txt
│
└── database/
    └── schema.sql          ← SQLite schema + full seed data
```

---

## 🚀 Quick Start

```bash
# 1. Install Python deps
cd backend/python
pip install -r requirements.txt

# 2. Start backend
python app.py
# Runs at http://localhost:5000

# 3. Open frontend
# Option A: Just open frontend/index.html in browser
# Option B: Serve with Python
cd frontend && python -m http.server 3000
# Visit http://localhost:3000
```

---

## 🔑 Demo Login

| Field | Value |
|-------|-------|
| Email or Reg. No. | `admin@academy.edu` |
| Password | `admin123` |

> **Offline Demo Mode**: If backend is not running, the site auto-loads built-in sample data. Login with `admin@academy.edu / admin123` still works.

---

## 📝 Sign Up Fields

The signup form collects:
- **Full Name** (student_name)
- **Registration Number** (e.g. REG2024001)
- **Department**
- **Email**
- **Password** + Confirm (min 6 chars)

---

## 📋 Features

| Feature | Description |
|---------|-------------|
| ✅ Login & Signup | Name, Email, Password, Reg. No. |
| ✅ Background Images | Unique Unsplash photo per page |
| ✅ Navigation | 5-item nav bar (Home, Students, Marks, Attendance, About) |
| ✅ Student Details | Search, filter, view, add students |
| ✅ Academic Marks | Full-year history, semester tabs, grade charts |
| ✅ Attendance | Subject-wise marking, bulk entry, % rings, detail modal |
| ✅ Offline Mode | Full demo data without backend |
| ✅ Responsive | Mobile-friendly hamburger nav |

---

## 🌐 Background Images (Unsplash)

| Page | Scene |
|------|-------|
| Login | University library at night |
| Dashboard | University campus building |
| Students | Lecture hall |
| Marks | Student studying / exams |
| Attendance | Classroom scene |
| About | Historic university architecture |

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/signup | Register (name, email, password, regno) |
| POST | /api/login | Login (email or regno + password) |
| GET | /api/students | All students |
| POST | /api/students | Add student |
| GET | /api/marks | All marks (full year) |
| POST | /api/marks | Add marks |
| GET | /api/marks/:id | Student marks |
| GET | /api/attendance | All attendance records |
| POST | /api/attendance | Add single record |
| POST | /api/attendance/bulk | Bulk mark attendance |
| GET | /api/attendance/summary | Per-student attendance % |
| GET | /api/history | Academy history |
| GET | /api/stats | Dashboard statistics |

---

*© 2024 Student Academy History System · Python + Java + SQLite*
