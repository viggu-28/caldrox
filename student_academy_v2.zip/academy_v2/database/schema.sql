-- ═══════════════════════════════════════════════════
-- STUDENT ACADEMY SYSTEM v2 — DATABASE SCHEMA
-- ═══════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    regno TEXT UNIQUE NOT NULL,
    role TEXT DEFAULT 'student',
    department TEXT DEFAULT 'General',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT UNIQUE NOT NULL,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    date_of_birth DATE,
    gender TEXT,
    email TEXT,
    phone TEXT,
    address TEXT,
    enrollment_year INTEGER,
    department TEXT,
    user_id INTEGER,
    profile_img TEXT DEFAULT '',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS academic_marks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT NOT NULL,
    subject TEXT NOT NULL,
    year INTEGER NOT NULL,
    semester TEXT NOT NULL,
    marks INTEGER NOT NULL,
    max_marks INTEGER DEFAULT 100,
    grade TEXT,
    teacher TEXT,
    remarks TEXT DEFAULT '',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id)
);

CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT NOT NULL,
    subject TEXT NOT NULL,
    date DATE NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('Present','Absent','Late','Excused')),
    marked_by TEXT DEFAULT 'System',
    remarks TEXT DEFAULT '',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id)
);

CREATE TABLE IF NOT EXISTS academy_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    event_date DATE,
    category TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ─── SEED DATA ────────────────────────────────────────

INSERT OR IGNORE INTO academy_history (title, description, event_date, category) VALUES
('Academy Founded','The Student Academy was established with a vision to provide world-class education.','1985-09-01','Milestone'),
('First Graduation Ceremony','The inaugural graduation ceremony celebrated 50 outstanding students.','1989-06-15','Ceremony'),
('Science Department Established','A dedicated science department was created to advance STEM education.','1992-03-10','Department'),
('International Accreditation','The academy received international accreditation for academic excellence.','2001-11-20','Achievement'),
('New Campus Inauguration','A state-of-the-art campus was inaugurated with modern learning facilities.','2010-01-05','Infrastructure'),
('Digital Learning Initiative','Launched digital classrooms and e-learning platforms for all students.','2018-07-22','Innovation'),
('Research Center Opening','The Academy Research Center was opened to promote innovation.','2022-04-18','Achievement');

-- Demo admin user (password: admin123)
INSERT OR IGNORE INTO users (student_name, email, password_hash, regno, role, department) VALUES
('Administrator','admin@academy.edu','admin:admin123','ADM0001','admin','Administration');

-- Sample students
INSERT OR IGNORE INTO students (student_id, first_name, last_name, date_of_birth, gender, email, phone, department, enrollment_year) VALUES
('STU001','Alice','Johnson','2002-04-15','Female','alice@academy.edu','555-0101','Computer Science',2023),
('STU002','Bob','Smith','2001-08-22','Male','bob@academy.edu','555-0102','Mathematics',2023),
('STU003','Carol','Williams','2003-01-10','Female','carol@academy.edu','555-0103','Physics',2023),
('STU004','David','Brown','2000-11-05','Male','david@academy.edu','555-0104','Chemistry',2023),
('STU005','Emma','Davis','2002-07-30','Female','emma@academy.edu','555-0105','Biology',2023);

-- Academic marks — Full year 2023-2024 (2 semesters × multiple subjects)
INSERT OR IGNORE INTO academic_marks (student_id, subject, year, semester, marks, max_marks, grade, teacher, remarks) VALUES
-- Alice - CS - Semester 1
('STU001','Data Structures',2023,'Semester 1',92,100,'A','Prof. Martinez','Excellent performance'),
('STU001','Discrete Mathematics',2023,'Semester 1',85,100,'B+','Prof. Lee','Good analytical skills'),
('STU001','Computer Architecture',2023,'Semester 1',88,100,'B+','Prof. Chen','Strong fundamentals'),
('STU001','English Communication',2023,'Semester 1',90,100,'A','Prof. Wilson','Outstanding'),
('STU001','Physics Lab',2023,'Semester 1',78,100,'B+','Prof. Patel','Satisfactory'),
-- Alice - CS - Semester 2
('STU001','Algorithms',2024,'Semester 2',95,100,'A+','Prof. Martinez','Top of class'),
('STU001','Database Systems',2024,'Semester 2',91,100,'A','Prof. Chen','Excellent project work'),
('STU001','Operating Systems',2024,'Semester 2',87,100,'B+','Prof. Kumar','Very good'),
('STU001','Web Development',2024,'Semester 2',96,100,'A+','Prof. Wilson','Exceptional creativity'),
('STU001','Statistics',2024,'Semester 2',83,100,'B','Prof. Lee','Needs more practice'),

-- Bob - Math - Semester 1
('STU002','Calculus II',2023,'Semester 1',91,100,'A','Prof. Taylor','Outstanding'),
('STU002','Linear Algebra',2023,'Semester 1',88,100,'B+','Prof. Anderson','Strong problem-solving'),
('STU002','Probability',2023,'Semester 1',85,100,'B+','Prof. Thomas','Good work'),
('STU002','English Communication',2023,'Semester 1',72,100,'B','Prof. Wilson','Average'),
('STU002','Physics',2023,'Semester 1',80,100,'B','Prof. Patel','Decent'),
-- Bob - Math - Semester 2
('STU002','Real Analysis',2024,'Semester 2',93,100,'A','Prof. Taylor','Excellent'),
('STU002','Number Theory',2024,'Semester 2',87,100,'B+','Prof. Anderson','Good'),
('STU002','Statistics',2024,'Semester 2',90,100,'A','Prof. Thomas','Great performance'),
('STU002','Numerical Methods',2024,'Semester 2',82,100,'B','Prof. Kumar','Satisfactory'),
('STU002','Computer Science Basics',2024,'Semester 2',76,100,'B+','Prof. Chen','Good effort'),

-- Carol - Physics - Semester 1
('STU003','Classical Mechanics',2023,'Semester 1',83,100,'B','Prof. Jackson','Good'),
('STU003','Electrodynamics',2023,'Semester 1',78,100,'B+','Prof. White','Average'),
('STU003','Mathematics for Physics',2023,'Semester 1',88,100,'B+','Prof. Taylor','Strong'),
('STU003','Lab Work I',2023,'Semester 1',90,100,'A','Prof. Jackson','Excellent practical skills'),
('STU003','English Communication',2023,'Semester 1',75,100,'B+','Prof. Wilson','Good'),
-- Carol - Physics - Semester 2
('STU003','Quantum Mechanics',2024,'Semester 2',79,100,'B+','Prof. Jackson','Satisfactory'),
('STU003','Thermodynamics',2024,'Semester 2',85,100,'B+','Prof. White','Good'),
('STU003','Optics',2024,'Semester 2',82,100,'B','Prof. Patel','Adequate'),
('STU003','Lab Work II',2024,'Semester 2',91,100,'A','Prof. Jackson','Outstanding'),
('STU003','Computer Applications',2024,'Semester 2',77,100,'B+','Prof. Chen','Decent'),

-- David - Chemistry - Semester 1
('STU004','Organic Chemistry',2023,'Semester 1',89,100,'B+','Prof. Harris','Strong'),
('STU004','Inorganic Chemistry',2023,'Semester 1',92,100,'A','Prof. Martin','Excellent'),
('STU004','Math for Chemistry',2023,'Semester 1',80,100,'B','Prof. Taylor','Good'),
('STU004','Lab Techniques',2023,'Semester 1',94,100,'A','Prof. Harris','Outstanding lab skills'),
('STU004','English Communication',2023,'Semester 1',70,100,'B','Prof. Wilson','Average'),
-- David - Chemistry - Semester 2
('STU004','Biochemistry',2024,'Semester 2',95,100,'A+','Prof. Martin','Top performer'),
('STU004','Physical Chemistry',2024,'Semester 2',88,100,'B+','Prof. Harris','Very good'),
('STU004','Analytical Chemistry',2024,'Semester 2',91,100,'A','Prof. Kumar','Excellent'),
('STU004','Research Methods',2024,'Semester 2',85,100,'B+','Prof. Martin','Good'),
('STU004','Computer Applications',2024,'Semester 2',74,100,'B+','Prof. Chen','Adequate'),

-- Emma - Biology - Semester 1
('STU005','Cell Biology',2023,'Semester 1',96,100,'A+','Prof. Garcia','Top of class'),
('STU005','Microbiology',2023,'Semester 1',91,100,'A','Prof. Rodriguez','Excellent'),
('STU005','Biochemistry Basics',2023,'Semester 1',88,100,'B+','Prof. Martin','Strong'),
('STU005','Lab Work I',2023,'Semester 1',93,100,'A','Prof. Garcia','Outstanding'),
('STU005','English Communication',2023,'Semester 1',85,100,'B+','Prof. Wilson','Very good'),
-- Emma - Biology - Semester 2
('STU005','Genetics',2024,'Semester 2',94,100,'A','Prof. Rodriguez','Excellent'),
('STU005','Ecology',2024,'Semester 2',89,100,'B+','Prof. Garcia','Strong'),
('STU005','Molecular Biology',2024,'Semester 2',92,100,'A','Prof. Kumar','Very good'),
('STU005','Biotechnology',2024,'Semester 2',87,100,'B+','Prof. Rodriguez','Good'),
('STU005','Statistics for Biology',2024,'Semester 2',80,100,'B','Prof. Thomas','Satisfactory');

-- Attendance data — Generate for each student across subjects (full year)
-- STU001 Alice Johnson
INSERT OR IGNORE INTO attendance (student_id, subject, date, status, marked_by) VALUES
('STU001','Data Structures','2023-08-01','Present','Prof. Martinez'),
('STU001','Data Structures','2023-08-08','Present','Prof. Martinez'),
('STU001','Data Structures','2023-08-15','Absent','Prof. Martinez'),
('STU001','Data Structures','2023-08-22','Present','Prof. Martinez'),
('STU001','Data Structures','2023-09-05','Present','Prof. Martinez'),
('STU001','Data Structures','2023-09-12','Late','Prof. Martinez'),
('STU001','Data Structures','2023-09-19','Present','Prof. Martinez'),
('STU001','Data Structures','2023-09-26','Present','Prof. Martinez'),
('STU001','Algorithms','2024-01-10','Present','Prof. Martinez'),
('STU001','Algorithms','2024-01-17','Present','Prof. Martinez'),
('STU001','Algorithms','2024-01-24','Present','Prof. Martinez'),
('STU001','Algorithms','2024-02-07','Absent','Prof. Martinez'),
('STU001','Algorithms','2024-02-14','Present','Prof. Martinez'),
('STU001','Algorithms','2024-02-21','Present','Prof. Martinez'),
('STU001','Web Development','2024-01-12','Present','Prof. Wilson'),
('STU001','Web Development','2024-01-19','Present','Prof. Wilson'),
('STU001','Web Development','2024-02-09','Present','Prof. Wilson'),
('STU001','Web Development','2024-02-16','Late','Prof. Wilson'),
('STU001','Web Development','2024-03-01','Present','Prof. Wilson'),
('STU001','Database Systems','2024-01-11','Present','Prof. Chen'),
('STU001','Database Systems','2024-01-18','Absent','Prof. Chen'),
('STU001','Database Systems','2024-02-08','Present','Prof. Chen'),
('STU001','Database Systems','2024-02-15','Present','Prof. Chen'),
('STU001','Database Systems','2024-03-07','Present','Prof. Chen'),
-- STU002 Bob Smith
('STU002','Calculus II','2023-08-02','Present','Prof. Taylor'),
('STU002','Calculus II','2023-08-09','Absent','Prof. Taylor'),
('STU002','Calculus II','2023-08-16','Present','Prof. Taylor'),
('STU002','Calculus II','2023-09-06','Present','Prof. Taylor'),
('STU002','Calculus II','2023-09-13','Late','Prof. Taylor'),
('STU002','Calculus II','2023-09-20','Present','Prof. Taylor'),
('STU002','Real Analysis','2024-01-10','Present','Prof. Taylor'),
('STU002','Real Analysis','2024-01-17','Present','Prof. Taylor'),
('STU002','Real Analysis','2024-01-24','Absent','Prof. Taylor'),
('STU002','Real Analysis','2024-02-07','Present','Prof. Taylor'),
('STU002','Real Analysis','2024-02-14','Present','Prof. Taylor'),
('STU002','Statistics','2024-01-15','Present','Prof. Thomas'),
('STU002','Statistics','2024-01-22','Present','Prof. Thomas'),
('STU002','Statistics','2024-02-12','Absent','Prof. Thomas'),
('STU002','Statistics','2024-02-19','Present','Prof. Thomas'),
('STU002','Statistics','2024-03-04','Present','Prof. Thomas'),
-- STU003 Carol
('STU003','Classical Mechanics','2023-08-03','Present','Prof. Jackson'),
('STU003','Classical Mechanics','2023-08-10','Present','Prof. Jackson'),
('STU003','Classical Mechanics','2023-08-17','Absent','Prof. Jackson'),
('STU003','Classical Mechanics','2023-09-07','Late','Prof. Jackson'),
('STU003','Classical Mechanics','2023-09-14','Present','Prof. Jackson'),
('STU003','Quantum Mechanics','2024-01-11','Present','Prof. Jackson'),
('STU003','Quantum Mechanics','2024-01-18','Absent','Prof. Jackson'),
('STU003','Quantum Mechanics','2024-01-25','Present','Prof. Jackson'),
('STU003','Quantum Mechanics','2024-02-08','Present','Prof. Jackson'),
('STU003','Lab Work II','2024-01-13','Present','Prof. Jackson'),
('STU003','Lab Work II','2024-01-20','Present','Prof. Jackson'),
('STU003','Lab Work II','2024-02-10','Present','Prof. Jackson'),
('STU003','Lab Work II','2024-02-17','Late','Prof. Jackson'),
-- STU004 David
('STU004','Organic Chemistry','2023-08-04','Present','Prof. Harris'),
('STU004','Organic Chemistry','2023-08-11','Present','Prof. Harris'),
('STU004','Organic Chemistry','2023-08-18','Present','Prof. Harris'),
('STU004','Organic Chemistry','2023-09-08','Absent','Prof. Harris'),
('STU004','Lab Techniques','2023-08-05','Present','Prof. Harris'),
('STU004','Lab Techniques','2023-08-12','Present','Prof. Harris'),
('STU004','Lab Techniques','2023-08-19','Late','Prof. Harris'),
('STU004','Biochemistry','2024-01-12','Present','Prof. Martin'),
('STU004','Biochemistry','2024-01-19','Present','Prof. Martin'),
('STU004','Biochemistry','2024-01-26','Present','Prof. Martin'),
('STU004','Biochemistry','2024-02-09','Absent','Prof. Martin'),
('STU004','Biochemistry','2024-02-16','Present','Prof. Martin'),
-- STU005 Emma
('STU005','Cell Biology','2023-08-01','Present','Prof. Garcia'),
('STU005','Cell Biology','2023-08-08','Present','Prof. Garcia'),
('STU005','Cell Biology','2023-08-15','Present','Prof. Garcia'),
('STU005','Cell Biology','2023-09-05','Late','Prof. Garcia'),
('STU005','Cell Biology','2023-09-12','Present','Prof. Garcia'),
('STU005','Genetics','2024-01-10','Present','Prof. Rodriguez'),
('STU005','Genetics','2024-01-17','Present','Prof. Rodriguez'),
('STU005','Genetics','2024-01-24','Present','Prof. Rodriguez'),
('STU005','Genetics','2024-02-07','Absent','Prof. Rodriguez'),
('STU005','Genetics','2024-02-14','Present','Prof. Rodriguez'),
('STU005','Molecular Biology','2024-01-11','Present','Prof. Kumar'),
('STU005','Molecular Biology','2024-01-18','Present','Prof. Kumar'),
('STU005','Molecular Biology','2024-02-08','Present','Prof. Kumar'),
('STU005','Molecular Biology','2024-02-15','Absent','Prof. Kumar'),
('STU005','Molecular Biology','2024-03-07','Present','Prof. Kumar');
